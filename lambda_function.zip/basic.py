echo "chaks da"
echo "fuck da now"
read line
echo $line
