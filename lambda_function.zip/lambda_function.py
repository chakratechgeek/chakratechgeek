def lambda_handler(event, context):
    # Lambda function logic goes here
    print ("Fuck her hard")
    return {
        'statusCode': 200,
        'body': 'Hello, from Lambda!'
    }
